FunGEN - Functional Game Engine
http://www.cin.ufpe.br/~haskell/fungen
Copyright (C) 2002  Andre Furtado <awbf@cin.ufpe.br>

Once you have set the HC, TOP, HC_OPT and HC_LIBS variables in the Makefile,

MAKE COMPILE is all you need to compile all FunGEn modules
MAKE will compile all the modules and compile and link a test file called game.hs
MAKE SINGLE will compile and link only game.hs

Hope to improve this install procedure in the future... :)
